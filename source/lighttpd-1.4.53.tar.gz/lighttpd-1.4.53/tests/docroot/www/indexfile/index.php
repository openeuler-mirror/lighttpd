<?php print $_SERVER["PHP_SELF"]; ?>
